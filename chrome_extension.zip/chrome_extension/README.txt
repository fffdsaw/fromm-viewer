Fromm Stream Nexus Proxy 1.0.2

압축을 풀었을 때 이 폴더 안에 manifest.json이 바로 있어야 합니다.
Chrome에서 chrome://extensions를 열고 개발자 모드를 켠 뒤
‘압축해제된 확장 프로그램을 로드’로 이 폴더를 선택하세요.

등록된 Fromm Viewer GitHub Pages 주소에서만 Fromm API와 미디어 요청의
CORS 헤더를 조정합니다. 인증 토큰을 저장하거나 전송하지 않습니다.
