Fromm Stream Nexus Proxy 1.0.1 — fffdsaw.github.io용

1. ZIP 압축을 풉니다.
2. Chrome에서 chrome://extensions 에 접속합니다.
3. 개발자 모드를 켜고 압축해제된 확장 프로그램을 로드합니다.
4. manifest.json이 들어 있는 chrome_extension 폴더를 선택합니다.
5. Fromm Viewer 페이지를 새로고침합니다.
